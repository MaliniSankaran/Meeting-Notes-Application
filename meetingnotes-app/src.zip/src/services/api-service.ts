


import { Note } from '../models/Note';

const BASE_URL = 'http://localhost:3000/meetingnotes';

export const fetchMeetingNotes = async (): Promise<Note[]> => {
  try {
    const response = await fetch(BASE_URL,{
      method:'GET',
  });
    if (!response.ok) throw new Error('Network response was not ok');
    return await response.json() as Note[];
  } catch (error) {
    console.error("Could not fetch meeting notes:", error);
    throw error;
  }
};

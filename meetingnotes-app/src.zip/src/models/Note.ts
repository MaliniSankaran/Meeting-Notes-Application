export interface ActionItem {
    text: string;
    completed: boolean;
  }
  
  export interface Note {
    id: string;
    title: string;
    content: string;
    created: string;
    updated?: string; 
    actionItems: ActionItem[];
  }
  
  
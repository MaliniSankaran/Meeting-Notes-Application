
import { useState, useEffect } from 'react'; // Hook
import './App.css';
 
import BrandBar from './pages/BrandBar';
import { Route, Routes } from 'react-router-dom';
import NotesList from './pages/NotesList';
import { fetchMeetingNotes } from './services/api-service'; // Import the function to fetch notes
import { Note } from './models/Note';
import { BrowserRouter as Router } from 'react-router-dom';
 
function App() {
  const [notes, setNotes] = useState<Note[]>([]); // Initialize notes state
 
  useEffect(() => {
    async function fetchNotes() {
      try {
        const fetchedNotes = await fetchMeetingNotes(); // Fetch notes from API
        setNotes(fetchedNotes); // Set notes state
      } catch (error) {
        console.error('Failed to fetch notes:', error);
      }
    }
    fetchNotes(); // Call fetchNotes on component mount
  }, []);
 
  return (
    <Router>
      <div>
        <BrandBar />
        <br/>
        <Routes>
        <Route path="/" element={<NotesList notes={notes} />} />
          {/* Define other routes here as needed */}
        </Routes>
      </div>
    </Router>
  );
}
 
export default App;
 